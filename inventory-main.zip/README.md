## ax-inventory
 
Make sure to rename qb-inventory to ax-inventory in qb-shops fxmanifest.lua or it may not work

![20210618181230_1](https://user-images.githubusercontent.com/66404074/122620901-21f4dd00-d062-11eb-95a7-1f8c64af06ed.jpg)
![20210618181219_1](https://user-images.githubusercontent.com/66404074/122620907-24573700-d062-11eb-844e-3867fa1175eb.jpg)
![20210618180812_1](https://user-images.githubusercontent.com/66404074/122620909-25886400-d062-11eb-8952-18ebc70c8b27.jpg)
![20210618180643_1](https://user-images.githubusercontent.com/66404074/122620929-2d480880-d062-11eb-9894-8c28e159ffbf.jpg)
